# Meet Recipe App Using HTML CSS And Javascript

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/ExMyZBE](https://codepen.io/Codewithshobhit/pen/ExMyZBE).

A fusion between a nav bar and a bottom sheet

Food vector created by stories - www.freepik.com
Icons by ProSymbols from the Noun Project
